#include<stdio.h>
#include<string.h>


void main()
{
FILE *ptr;
int i,n;
char arr[10][10], str;

if((ptr=fopen("in_con.txt",r+)== NULL)
{
	printf("\n Error in opening the file!");
	exit(0);
}

fscanf(ptr,"%s",str);
fclose(ptr);
printf("%s",str);
}
